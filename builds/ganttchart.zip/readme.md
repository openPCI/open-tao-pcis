#Gantt exercise
The gantt exercise allows for a test-taker to fill a predefined gantt chart.
