#Gantt excersize
The gantt excersize allows for a test-taker to fill a predefined gantt chart.
