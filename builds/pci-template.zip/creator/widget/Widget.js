/*
 * Boiler plating for PCI module.
 */
define([
    'taoQtiItem/qtiCreator/widgets/interactions/customInteraction/Widget',
    '%pci-identifier%/creator/widget/states/states'
], function(Widget, states){
    'use strict';

    var %pci-identifier%Widget = Widget.clone();

     %pci-identifier%Widget.initCreator = function(){

        this.registerStates(states);

        Widget.initCreator.call(this);
    };

    return %pci-identifier%Widget;
});
