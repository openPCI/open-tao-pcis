/*
 * Define settings for widget here
 */
define([], function(){
    'use strict';
    return {
      'strings' : ['textarea','Tekster', ''],
      'areas' : ['textarea','Områder', '']
    };
});
