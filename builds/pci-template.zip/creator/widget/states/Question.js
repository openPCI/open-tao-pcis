define([
    '%pci-identifier%/creator/widget/settings'
    'taoQtiItem/qtiCreator/widgets/states/factory',
    'taoQtiItem/qtiCreator/widgets/interactions/states/Question',
    'taoQtiItem/qtiCreator/widgets/helpers/formElement',
    'taoQtiItem/qtiCreator/editor/simpleContentEditableElement',
    'taoQtiItem/qtiCreator/editor/containerEditor',
    'tpl!%pci-identifier%/creator/tpl/propertiesForm',
    'lodash',
    'jquery'
], function(widgetSettings, stateFactory, Question, formElement, simpleEditor, containerEditor, formTpl, _, $){
    'use strict';


    var %pci-identifier%StateQuestion = stateFactory.extend(Question, function(){

        var $container = this.widget.$container,
            interaction = this.widget.element

        //previewChat($container);

    }, function(){

        var Scontainer = this.widget.$container,
            Sprompt = Scontainer.find('.prompt');

        simpleEditor.destroy(Scontainer);
        containerEditor.destroy(Sprompt);
    });

     %pci-identifier%StateQuestion.prototype.initForm = function(){

        var _widget = this.widget,
            Sform = _widget.$form,
            interaction = _widget.element,
            response = interaction.getResponseDeclaration();

        var formVariables = {};
        var changeCallbacks = {};
        var settingsArr = [];

        widgetSettings.keys().forEach(function(key){
          var propInfo = widgetSettings[key];
          var info = {name: key, info: propInfo, value: interaction.prop(key)};
          if(propInfo[0] == 'textarea') info.textarea = true;
          settingsArr.push(info);

          formVariables[key] = interaction.prop(key);
          changeCallbacks[key] = function(interaction, value){
            if(propType == 'int') value = parseInt(value);
            interaction.prop(key, value);
            interaction.triggerPci('cfgChange', [key,value]);
          }
        });

        formvariables['widgetSettings'] = settingsArr;
        formVariables['identifier'] = interaction.attr('responseIdentifier');
        formVariables['serial'] = response.serial;

        changeCallbacks['identifier'] = function(i, value){
            response.id(value);
            interaction.attr('responseIdentifier', value);
        };



        //render the form using the form template
        Sform.html(formTpl(formVariables));

        //init form javascript
        formElement.initWidget(Sform);

        //init data change callbacks
        formElement.setChangeCallbacks(Sform, interaction, changeCallbacks);

    };

    return  %pci-identifier%StateQuestion;
});
