

/*
Build by Wiquid's PCI Generator for TAO platform Free to use
 */

define([
    'lodash',
    '%pci-identifier%/creator/widget/Widget',
    'tpl!%pci-identifier%/creator/tpl/markup',
    '%pci-identifier%/creator/widget/settings'
], function(_, Widget, markupTpl, settings){
    'use strict';

    var _typeIdentifier = '%pci-identifier%';

    var %pci-identifier%Creator = {
        /**
         * (required) Get the typeIdentifier of the custom interaction
         *
         * @returns {String}
         */
        getTypeIdentifier : function(){
            return _typeIdentifier;
        },

        /**
         * (required) Get the widget prototype
         * Used in the renderer
         *
         * @returns {Object} Widget
         */
        getWidget : function(){
            console.log('getWidget', arguments, Widget);
            window.editor_mode = true;
            return Widget;
        },

        /**
         * (optional) Get the default properties values of the pci.
         * Used on new pci instance creation
         *
         * @returns {Object}
         */
        getDefaultProperties : function(pci){
          var defaults = {}
          settings.keys().forEach(function(key){
            var info = settings[key];
            defaults[key] = info[2];
          });
          return defaults;
        },
        /**
         * (optional) Callback to execute on the
         * Used on new pci instance creation
         *
         * @returns {Object}
         */
        afterCreate : function(pci){
            //do some stuff
            console.log('afterCreate', arguments);
        },
        /**
         * (required) Gives the qti pci xml template
         *
         * @returns {function} handlebar template
         */
        getMarkupTemplate : function(){
            console.log('getMarkupTemplate', arguments);
            return markupTpl;
        },
        /**
         * (optional) Allows passing additional data to xml template
         *
         * @returns {function} handlebar template
         */
        getMarkupData : function(pci, defaultData){
            console.log('getMarkupData', arguments);
            defaultData.prompt = pci.data('prompt');
            return defaultData;
        }
    };

    //since we assume we are in a tao context, there is no use to expose the a global object for lib registration
    //all libs should be declared here
    return %pci-identifier%Creator;
});
