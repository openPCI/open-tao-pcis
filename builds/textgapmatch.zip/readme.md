# Textgapmatch
This PCI allows a test taker to drag & drop labels onto areas defined on top of an image.
