# Brainstorm
Brainstorm is a simulated chat exercise for brainstorming scenarios.
The test-taker will have to participate in a simulated brainstorm group chat.
Other participants are "bots" that respond with suggestions when the test-taker has not given input within a certain timelimit.

"bot" messages are inputted in the designated textarea in TAO editor.
Each line must be consist of a Name, Color, Delay and Message, semi-colon separated.

Example:
```CSV
5;Anne;darkred;En stor samling af økser
10;Kai;green;Film om hvordan vikingerne boede
14;Eske;#00a8a7;Bygge økser
```
